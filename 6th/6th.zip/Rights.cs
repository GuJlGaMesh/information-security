﻿
namespace _6th
{
	public enum AccessRights
	{
		Read,
		Write,
		Grant,
		Forbidden
	}
}
